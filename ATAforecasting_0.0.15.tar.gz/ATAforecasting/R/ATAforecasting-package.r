#' @export(ATA)
#' @export(ATA.Forecast)
#' @export(ATA.Decomposition)
#' @export(ATA.Accuracy)
#' @import(Rcpp)
#' @import(stats)
#' @import(graphics)
#' @import(forecast)
#' @import(Mcomp)
#' @import(xts)
#' @import(stR)
#' @import(stlplus)
#' @import(timeSeries)
#' @useDynLib ATAforecasting, .registration = TRUE
NULL

#' @export